# 🔐 Gartner Identity 2025 — Soluciones de Identidad (IDV, IAM, IGA)

Repositorio educativo con información pública de los cuadrantes de Gartner 2025 para gestión de identidad:
- Identity Verification (IDV)
- Access Management (AM)
- Identity Governance & Administration (IGA)

Incluye archivos Excel y gráficos generados automáticamente (mapa general y cuadrante IDV).

## 📈 Contenido
- `Gartner_Identidad_2025.xlsx` — Tabla consolidada
- `Gartner_Identidad_2025.png` — Mapa comparativo (IDV, AM, IGA)
- `Gartner_IDV_Quadrant_2025.png` — Cuadrante clásico (IDV)

## 📜 Licencia
Distribución educativa y sin fines comerciales.
